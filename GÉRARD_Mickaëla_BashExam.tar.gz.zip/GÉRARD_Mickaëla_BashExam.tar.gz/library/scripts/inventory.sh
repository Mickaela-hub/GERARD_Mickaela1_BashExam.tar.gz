#script qui liste tous les livres dans le iventory.txt et donne les statistiques execice 2.3

#!/bin/bash
set -e


echo "Voulez vous voir la liste des livres ajoutées ?"
read reponse

case $reponse in
Oui)
cat ~/library/books.txt
;;
OUI)
cat ~/library/books.txt
;;
oui)
cat ~/library/books.txt
;;
*)
echo "Vous avez choisis non"
;;
esac

echo "Pour savoir : Le nombre total de livres : Tapez 1"
echo "Pour voir la liste des livres rangée par planète : Tapez 2"
echo "Pour voir la liste des livres rangée par année : Tapez 3"
read choix

case $choix in
1)
echo "Nombre de livres répertoriés : "
ls | wc -l ~/library/books.txt
;;
2)
echo "Parmis la liste de Planète suivante, de quelle Planète souhaitez vous voir les livres ?"
echo "Terre - Jupiter - Mars"
read planete
if [[ $planete -eq Terre ]]; then
grep -i $planete ~/library/books.txt
fi
;;
3)
echo "De quelle année voulez vous voir les livres répertoriés ?"
read annee
grep -i $annee ~/library/books.txt
;;
*)
echo "Votre selection est incorrecte, Veuillez relancer la demande"
;;
esac


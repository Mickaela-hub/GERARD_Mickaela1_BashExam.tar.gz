#Exercice 3.1 système de journalisation (pas assez de temps pour trouver comment l'automatiser)

#!/bin/bash

echo "Vous voulez voir les opérations effectuées ? Tapez 1"
read reponse1

if [[ $reponse1 -eq 1 ]]
then
echo "Ecrivez exit dans le terminal, puis écrivez : nano ~/library/scripts/logger.txt"
else
echo "Vous n'avez pas tapé 1. Si vous voulez voir les opérations effectuées relancez le script"
fi

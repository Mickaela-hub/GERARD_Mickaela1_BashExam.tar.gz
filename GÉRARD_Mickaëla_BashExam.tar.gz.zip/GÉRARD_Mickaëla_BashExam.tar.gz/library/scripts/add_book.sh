#Ajout de livres

#!/bin/bash

while [ -z $titre ] #le z signifie tant que ce n'est pas egal à zero
do
echo "Veuillez saisir le titre du livre : "
echo "(Ne mettez pas d'espace ! Si le titre est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read titre
done
echo "Le titre de ce livre est : $titre"

while [ -z $auteur ]
do
echo "Veuillez saisir l'auteur du livre : "
echo "(Ne mettez pas d'espace ! Si l'auteur est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read auteur
done
echo "L'auteur de ce livre est : $auteur"

while [ -z $annee ]
do
echo "Veuillez saisir l'année de publication du livre :"
read annee
done
echo "L'année de publication de ce livre est : $annee"

while [ -z $planete ]
do
echo "Veuillez saisir la planète d'origine du livre : "
echo "(Ne mettez pas d'espace ! Si la planète d'origine est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read planete
done
echo "La planète d'origine de ce livre est : $planete"

while [ -z $ISBN ]
do
echo "Veuillez saisir l'ISBN Galactique du livre :"
read ISBN
done
echo "L'ISBN de ce livre est : $ISBN"

echo "Récapitulatif : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN"
echo "Vous validez votre saisie ? (Répondre par oui ou par non)"
read validation

while [ -z $validation ]
do
echo "Vous n'avez pas saisie de réponse"
read validation
done
eccho "hello" 2> ~/library/logs/error.txt

if  [[ $validation = oui ||  Oui || OUI ]]; then
echo "Le livre est ajoutée à la bibliothèque le :" $(date)
echo "Livre ajouté : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN - Ajouté le : " $(date) | cat >> ~/library/books.txt
echo "Livre ajouté : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN - Ajouté le : " $(date) | cat >> ~/library/logs/Livresajoutés.txt
elif [[ $validation = non || $validation = Non || $validation = NON ]]; then
echo "L'ajout du livre est annulé"
else
echo "L'ajout du livre est annulé"
fi


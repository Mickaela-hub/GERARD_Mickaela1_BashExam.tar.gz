#!/bin/bash
set -e


#LISTE BDD = liste des noms des bases de donnÉes de notre serveur
#save_BD = save dans logs
#backup_script.sh = backup.sh


DATE='date +%y_%m%d'

#On liste nos bases de données
LISTEBDD=$( echo 'show databases' | mysql -u backup--password=< mot de passe >)
for BDD in $LISTEBDD do
#Exclusion des BDD information_schema, mysql et Database
if [[ $BDD != "information_schema" ]] && [[ $BDD != "mysql"}} && [[ $BDD != "Database" ]]; then
#emplacement du dossier ou nous allons stocker les bases de données, un dossier par base de données
CHEMIN = ~/library/logs/save
# On backup notre base de données
mysqldump -u backup--single-transaction--password=< le mot de passe > $BDD > "$CHEMIN/$BDD.sql"_"$DATE.sql"
echo "|Sauvegarde de la base de donnees $BDD.sql";
fi
done


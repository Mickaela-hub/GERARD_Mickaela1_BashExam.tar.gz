#Recherche de livres exercice 2.2


#!/bin/bash
set -e

echo "Voulez vous chercher un livre ?"
read chercher

while [ -z $chercher ] #le z signifie tant que c'est egal à zero
do
echo "Je n'ai pas compris. Voulez vous chercher un livre ?"
read chercher
done

case $chercher in
(oui)
echo "Souhaitez vous chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ?"
read comment
while [ -z $comment ]
do
echo "Souhaitez vous  chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ? "
read comment
done
;;
(Oui)
echo "Souhaitez vous chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ?"
read comment
while [ -z $comment ]
do
echo "Souhaitez vous  chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ? "
read comment
done
;;
(OUI)
echo "Souhaitez vous chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ?"
read comment
while [ -z $comment ]
do
echo "Souhaitez vous  chercher ce livre grâce au titre, à l'auteur ou à l'ISBN ? "
read comment
done
;;
(non)
echo "La recherche de livre est annulée"
;;
(Non)
echo "La recherche de livre est annulée"
;;
(NON)
echo "La recherche de livre est annulée"
;;
(*)
echo "La recherche de livre est annulée"
echo "Si vous voulez chercher un livre. Veuillez relancer la recherche"
;;
esac

if [[ $chercher -eq oui || $chercher -eq Oui || $chercher -eq OUI && $comment -eq titre || $comment -eq Titre || $comment -eq TITRE || $comment -eq auteur || $comment -eq Auteur ||$comment -eq AUTEUR || $comment -eq ISBN ||$comment -eq isbn || $comment -eq Isbn ]]; then
case $comment in
titre)
echo "Quel est le titre de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read titre
while [ -z $titre ]
do
echo "Saisissez un titre de livre (Remplacer les espaces par un tiret bas <<_>>) "
read titre
done
echo "Recherche en cours ..."
grep -P -i "(?<=Titre\s:\s)$titre" ~/library/books.txt
#cette commande permet de trouver un mot selon la reponse de l'utilisateur en limitant la casse avec les majuscules
#entre les guillemets on l'inscrit de cette facon pour avoir le livre dont le mot recherchÉ est bien devant titre et pas auteur par exemple
echo "Recherche terminée"
;;
Titre)
echo "Quel est le titre de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read titre
while [ -z $titre ]
do
echo "Saisissez un titre de livre (Remplacer les espaces par un tiret bas <<_>>) "
read titre
done
echo "Recherche en cours ..."
grep -P -i "(?<=Titre\s:\s)$titre" ~/library/books.txt
echo "Recherche terminée"
;;
TITRE)
echo "Quel est le titre de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read titre
while [ -z $titre ]
do
echo "Saisissez un titre de livre (Remplacer les espaces par un tiret bas <<_>>) "
read titre
done
echo "Recherche en cours ..."
grep -P -i "(?<=Titre\s:\s)$titre" ~/library/books.txt
echo "Recherche terminée"
;;
auteur)
echo "Quel est l'auteur de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
while [ -z $auteur ]
do
echo "Saisissez l'auteur de ce livre (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
done
echo "Recherche en cours ..."
grep -P -i "(?<=Titre\s:\s)$titre" ~/library/books.txt
echo "Recherche terminée"
;;
Auteur)
echo "Quel est l'auteur de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
while [ -z $auteur ]
do
echo "Saisissez l'auteur de ce livre (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
done
echo "Recherche en cours ..."
grep -P -i "(?<=Auteur\s:\s)$auteur" ~/library/books.txt
echo "Recherche terminée"
;;
AUTEUR)
echo "Quel est l'auteur de ce livre ? (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
while [ -z $auteur ]
do
echo "Saisissez l'auteur de ce livre (Remplacer les espaces par un tiret bas <<_>>) "
read auteur
done
echo "Recherche en cours ..."
grep -P -i "(?<=Auteur\s:\s)$auteur" ~/library/books.txt
echo "Recherche terminée"
;;
ISBN)
echo "Quel est l'ISBN de ce livre ?"
read ISBN
while [ -z $ISBN ]
do
echo "Saisissez l'ISBN de ce livre"
read ISBN
done
echo "Recherche en cours ..."
grep -P -i "(?<=ISBN\s:\s)$ISBN" ~/library/books.txt
echo "Recherche terminée"
;;
Isbn)
echo "Quel est l'ISBN de ce livre ?"
read ISBN
while [ -z $ISBN ]
do
echo "Saisissez l'ISBN de ce livre"
read ISBN
done
echo "Recherche en cours ..."
grep -P -i "(?<=ISBN\s:\s)$ISBN" ~/library/books.txt
echo "Recherche terminée"
;;
isbn)
echo "Quel est l'ISBN de ce livre ?"
read ISBN
while [ -z $ISBN ]
do
echo "Saisissez l'ISBN de ce livre"
read ISBN
done
echo "Recherche en cours ..."
grep -P -i "(?<=ISBN\s:\s)$ISBN" ~/library/books.txt
echo "Recherche terminée"
;;
*)
echo  "Je n'ai pas compris. Si vous voulez chercher un livre. Veuillez relancer la recherche"
esac
else
echo  "Je n'ai pas compris votre demande. Si vous voulez chercher un livre. Veuillez relancer la recherche"
fi

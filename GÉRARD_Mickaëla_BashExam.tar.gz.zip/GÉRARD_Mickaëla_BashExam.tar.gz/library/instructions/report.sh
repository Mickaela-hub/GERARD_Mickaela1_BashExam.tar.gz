#Exercice 3.3
#Créer un script qui génère un rapport


#je commence toujours mes scripts par ces deux lignes pour spécifier le bash et arrêter le script s'il y a une erreur
#!/bin/bash
set -e


echo " ===  STATISTIQUES DU " $(date) "  === "
#Faute de temps pour trouver comment passer des lignes j'ai utilisé un echo vide
echo " "
#j'ai créer le script logger.sh qui inscrit les opérations enregistrées dans le fichier logger.txt que j ai créer
echo "Le nombre d'opérations répertoriés : "
#Donc je n'avais plus qu à compter le nombre de lignes de ce fichier pour avoir le nombre d opération
wc -l ~/library/scripts/logger.txt
echo " "
echo "Dernière modification de la bibliothèque le :"
#Après plusieurs recherches et essais
#j'ai trouvé cette commande qui permet d afficher la dernière modification d un fichier
stat ~/library/books.txt --format='%x'
echo " "
echo "Les livres répertoriés : "
echo " "
#Affiche simplement le contenu du fichier où tous les livres ont été enregistrés
cat ~/library/books.txt
#echo "Recherches effectuées : (commande pas terminée)

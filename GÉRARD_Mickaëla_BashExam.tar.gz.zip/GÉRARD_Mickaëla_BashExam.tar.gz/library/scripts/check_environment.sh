#Validation de l'environnement exercice 1.2

#!/bin/bash
set -e


#Vérification des fichiers, si ils n'existent pas le script le créer

#Vérification du dossier library
if [ ! -d ~/library ] ; then
echo "Le dossier n'existe pas, création du dossier en cours"
mkdir ~/library
fi

#Vérification du fichier books.txt
if [ ! -f ~/library/books.txt ];then
echo "Le fichier books.txt n'existe pas, création du fichier en cours"
touch ~/library/books.txt
fi

#Vérification du fichier users.txt
if [ ! -f ~/library/users.txt ];then
echo "Le fichier users.txt n'existe pas, création du fichier en cours"
touch ~/library/users.txt
fi

#Vérification du dossier logs
if [ ! -d ~/library/logs ];then
echo "Le dossier logs n'existe pas, création du dossier en cours"
mkdir ~/library/logs
fi

#Vérification du dossier scripts
if [ ! -d ~/library/scripts ];then
echo "Le dossier scripts n'existe pas, création du fichier en cours"
mkdir ~/library/scripts
fi


#Vérification des permissions l40
if [ -d ~/library  ] ; then
chmod 766 ~/library
fi

if [ -d ~/library/scripts ]; then
chmod 766 ~/library/scripts
fi

if [ -f ~/library/scripts/setup.sh ]; then
chmod 766 ~/library/scripts/setup.sh
fi

if [ -f ~/library/books.txt ]; then
chmod 766 ~/library/books.txt
fi

if [ -f ~/library/users.txt ]; then
chmod 766 ~/library/users.txt
fi

if [ -d ~/library/logs ]; then
chmod 766 ~/library/logs
fi

if [ -d ~/library/scripts/setup.sh ]; then
chmod 766 ~/library/scripts/setup.sh
fi

if [ -f ~/library/scripts/add_book.sh ]; then
chmod 766 ~/library/scripts/add_book.sh
fi

if [ -f ~/library/scripts/search_book.sh ]; then
chmod 766 ~/library/scripts/search_book.sh
else
echo "erreur"
fi

if [ -f ~/library/scripts/inventory.sh ]; then
chmod 766 ~/library/scripts/inventory.sh
else
echo "erreur"
fi

if [ -f ~/library/scripts/logger.sh ]; then
chmod 766 ~/library/scripts/logger.sh
else
echo "erreur"
fi

if [ -f ~/library/scripts/backup.sh ]; then
chmod 766 ~/library/scripts/backup.sh
else
echo "erreur"
fi

if [ -f ~/library/scripts/report.sh ]; then
chmod 766 ~/library/scripts/report.sh
else
echo "erreur"
fi

#Afficher un rapport détaillé

if [[ -d ~/library && -f ~/library/books.txt && -f ~/library/users.txt && -d ~/library/logs && -d ~/library/scripts && -f ~/library/scripts/setup.sh ]] ; then
echo "Les dossiers library, logs et scripts existent"
echo "Les fichiers books.txt, users.txt et setup.sh existent."
else
echo "Certains dossiers ou fichier sont inexistants"
fi

if [[ -r ~/library && -r ~/library/books.txt && -r ~/library/users.txt && -r ~/library/logs && -r ~/library/scripts && -w ~/library && -w ~/library/books.txt && -w ~/library/users.txt && -w ~/library/logs && -w ~/library/scripts ]]; then
echo "library, books.txt, users.txt, logs, scripts et setup.sh ont les autorisations suivantes : "
echo "Propriétaire : Ecrire, lire et executer"
echo "Groupe : Lire et écrire"
echo "Autres utilisateurs : Lire et écrire"
else
echo "Certains dossiers ou fichiers n'ont pas les permissions adaptées"
fi

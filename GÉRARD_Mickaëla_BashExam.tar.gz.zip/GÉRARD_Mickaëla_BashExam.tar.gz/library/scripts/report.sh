#!/bin/bash

set -e

echo " ===  STATISTIQUES DU " $(date) "  === "
echo " "
echo "Le nombre d'opération aujourd'hui : "
wc -l ~/library/scripts/logger.txt
echo " "
echo "Dernière modification de la bibliothèque le :"
stat ~/library/books.txt --format='%x'
echo " "
echo "Les livres répertoriés : "
echo " "
cat ~/library/books.txt
#echo "Recherches effectuées : (commande pas terminée)

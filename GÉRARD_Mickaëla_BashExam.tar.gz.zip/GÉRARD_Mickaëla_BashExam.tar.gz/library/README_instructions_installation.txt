#Pour l'intallation correcte veuillez suivre les étapes ci-dessous 

#1 lancez le script setup.sh avec ~/library/scripts/setup.sh en cliquant sur "lancer comme un programme"
#2 Puis lancez le script check_environment dans le même doosier pour vérifier l'existence des dossiers/fichiers et
#leurs permissions
#3 Lancer ~/library/instructions/add_book.sh et suivez les instructions qui s'affiche pour ajouter 
#un livre dans la bibliothèque
#Notre bibliothèque s'appelle books.txt dans le dossier library
#Vous pouvez directement voir les livres déjà ajoutés dans le contenu
#Pour chercher un livre lancer le script search_book.sh et suivez les instructions qui s'affiche
#Pour voir le nombre total de livre, ou la liste de livre par Planète ou par année, lancez le script :
# inventory.sh
#Lancer le scripts report.sh pour avoir le rapport qui indique le nombre d'opérations répertoriés, 
#la date de la dernière modification de la bibliothèque et la liste des livres répertoriés avec leurs dates d'ajout.

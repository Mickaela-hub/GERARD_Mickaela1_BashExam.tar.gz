#Ajout de livres

#!/bin/bash


#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $titre ] #le z signifie tant que ce n'est pas egal à zero
do
echo "Veuillez saisir le titre du livre : "
#demander a ne pas mettre d'espace sinon cela créer une erreur lors de la recherche
echo "(Ne mettez pas d'espace ! Si le titre est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read titre
done
#Renvoie la valeur saisi pour rassurer l'utilisateur sur sa saisi
echo "Le titre de ce livre est : $titre"

#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $auteur ]
do
echo "Veuillez saisir l'auteur du livre : "
echo "(Ne mettez pas d'espace ! Si l'auteur est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read auteur
done
#Renvoie la valeur saisi pour rassurer l'utilisateur sur sa saisi
echo "L'auteur de ce livre est : $auteur"

#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $annee ]
do
#ici je ne demande pas à ne pas mettre d'espace car on parle en année
echo "Veuillez saisir l'année de publication du livre :"
read annee
done
#Renvoie la valeur saisi pour rassurer l'utilisateur sur sa saisi
echo "L'année de publication de ce livre est : $annee"

#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $planete ]
do
echo "Veuillez saisir la planète d'origine du livre : "
#demander a ne pas mettre d'espace sinon cela créer une erreur lors de la recherche
echo "(Ne mettez pas d'espace ! Si la planète d'origine est composée de plusieurs mots veuillez les séparer avec un tiret bas <<_>> )"
read planete
done
#Renvoie la valeur saisi pour rassurer l'utilisateur sur sa saisi
echo "La planète d'origine de ce livre est : $planete"

#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $ISBN ]
do
#ici je ne demande pas à ne pas mettre d'espace car on parle de ISBN donc les gens vont inscrire une suite de caractères ou une suite de chiffre
echo "Veuillez saisir l'ISBN Galactique du livre :"
read ISBN
done
#Renvoie la valeur saisi pour rassurer l'utilisateur sur sa saisi
echo "L'ISBN de ce livre est : $ISBN"
echo "Récapitulatif : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN"
#Ici je rajoute répondre par oui ou non car mon script ne gère que les oui les non et
#(dans le cas ou les personnes écrit quand même une autre valeur par erreur)
#les autres termes sont considérés comme un non
#J'ai ajouté cette option de récapitulatif de la saisie que je trouvais sympa à créer :)
echo "Vous validez votre saisie ? (Répondre par oui ou par non)"
read validation

#Tant que l'utilisateur écris une valeur nulle alors il repose la question. Le but ? Avoir une valeur
while [ -z $validation ]
do
echo "Vous n'avez pas saisie de réponse"
read validation
done

#J'ai créer cette erreur pour essayer de créer un scripts qui enregistre les erreurs automatiquement pour
#l'exercice 3.3
#mais je manque de temps pour le pofiner donc je laisse cette erreur qui n'a pas d impact sur la suite du code
#dans le but de réessayer plus tard
eccho "hello" 2> ~/library/logs/error.txt


#Si l'uilisateur valide sa selection, le livre est ajouté à la bibliothêque et le fichier dans log pour
#enregistrer les ajouts
#j'ai ajouté la date je trouvais cela pratique si je me met à la place de quelqu un qui gère une vraie bibliothêque
if  [[ $validation = oui ||  Oui || OUI ]]; then
echo "Le livre est ajoutée à la bibliothèque le :" $(date)
echo "Livre ajouté : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN - Ajouté le : " $(date) | cat >> ~/library/books.txt
echo "Livre ajouté : Titre : $titre - Auteur : $auteur - Année de publication : $annee - Planète d'origine : $planete - ISBN : $ISBN - Ajouté le : " $(date) | cat >> ~/library/logs/Livresajoutés.txt
elif [[ $validation = non || $validation = Non || $validation = NON ]]; then
echo "L'ajout du livre est annulé"
else
echo "L'ajout du livre est annulé"
fi


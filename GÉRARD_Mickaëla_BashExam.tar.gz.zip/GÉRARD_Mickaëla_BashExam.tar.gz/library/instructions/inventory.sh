#script qui liste tous les livres dans le iventory.txt et donne les statistiques execice 2.3

#!/bin/bash
set -e


echo "Voulez vous voir la liste des livres repertoriés ?"
read reponse

#Si la réponse est oui alors cela affiche tous les livres ajoutés, j'aurais aimé avoir du temps pour trouver comment
#mettre seulement ceux ajoutés le jour actuel, mais au moins les livres du jour sont inscrit avec la date donc 
#on peut voir les livres ajoutés le jour même en regardant la date
case $reponse in
Oui)
cat ~/library/books.txt
;;
OUI)
cat ~/library/books.txt
;;
oui)
cat ~/library/books.txt
;;
*)
echo "Vous avez choisis non"
;;
esac

#j'ai créer tapez 1,2 et 3 pour être efficace
echo "Pour savoir : Le nombre total de livres : Tapez 1"
echo "Pour voir la liste des livres rangée par planète : Tapez 2"
echo "Pour voir la liste des livres rangée par année : Tapez 3"
read choix

case $choix in
1)
echo "Nombre de livres répertoriés : "
#sachant que le script qui ajoute les livres dispose un livre par ligne si on compte simplement les lignes du fichier
#avec la commande wc -l on obtient pas seulement le nombre de ligne mais le nombre de livre également
ls | wc -l ~/library/books.txt
;;
2)
echo "Parmis la liste de Planète suivante, de quelle Planète souhaitez vous voir les livres ?"
#J'ai préférée ajouter une selection pour limiter la casse
echo "Terre - Jupiter - Mars"
read planete
if [[ $planete -eq Terre ]]; then
echo "Recherche en cours ..."
grep -P -i "(?<=Planète\s:\s)$planete" ~/library/books.txt
#cette commande permet de trouver un mot selon la reponse de l'utilisateur en limitant la casse avec les majuscules
#entre les guillemets on l'inscrit de cette facon pour avoir le livre dont le mot recherché est bien devant
#le mot planète et pas auteur par exemple
echo "Recherche terminée"
fi
;;
3)
#j'aurais aimé avoir plus de temps pour trouver comment on classe par siècle
#À la place j'ai au moins donné la possibilité de voir par année
echo "De quelle année voulez vous voir les livres répertoriés ?"
read annee
grep -i $annee ~/library/books.txt
echo "Recherche en cours ..."
grep -P -i "(?<=Année\s:\s)$annee" ~/library/books.txt
echo "Recherche terminée"
;;
*)
echo "Votre selection est incorrecte, Veuillez relancer la demande"
;;
esac

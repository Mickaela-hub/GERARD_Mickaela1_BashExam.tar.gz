 #Création de l'environnement exercice 1.1

#!/bin/bash
set -e

#Lance l'enregistrement des opérations dans le fichier logger.txt
script ~/library/scripts/logger.txt

#Donne les permissions à logger.txt
chmod 777 ~/library/scripts/logger.txt

#condition si le dossier library n'existe pas alors il le créer et lui donne les permissions
if [ ! -d ~/library ]; then
mkdir ~/library
fi
chmod 766 ~/library

#condition si le fichier books.txt n'existe pas alors il le créer et lui donne les permissions
if [ ! -f ~/library/books.txt ]; then
touch ~/library/books.txt #Base de données des livres
fi
chmod 766 ~/library/books.txt
 #Tout les droits au propriétaire et droits d'écriture et de lecture pour le groupe et les autres utilisateurs


#condition si le fichier users.txt n'existe pas alors il le créer, puis écris un commentaire 
#et lui donne les permissions
if [ ! -f ~/library/users.txt ]; then
touch ~/library/users.txt #Base de données des utilisateurs
fi
echo "#Base des données des utilisateurs" | cat >> ~/library/users.txt
chmod 766 ~/library/users.txt


#condition si le dossier logs n'existe pas alors il le créer et lui donne les permissions
if [ ! -d ~/library/logs ]; then
mkdir ~/library/logs #Dossier des journaux
fi
chmod 766 ~/library/logs


#condition si le dossier scripts n'existe pas alors il le créer et lui donne les permissions
if [ ! -d ~/library/scripts ]; then
mkdir scripts #Mes scripts
fi
chmod 766 ~/library/scripts


#condition si le fichier setup.log n'existe pas alors il le créer, puis lui donne les permissions
#et écris un commentaire

if [ ! -f ~/library/scripts/setup.log ]; then
touch ~/library/scripts/setup.log
fi
chmod 766 ~/library/scripts/setup.log
echo "#Liste de chaque étape" | cat >> ~/library/scripts/setup.log

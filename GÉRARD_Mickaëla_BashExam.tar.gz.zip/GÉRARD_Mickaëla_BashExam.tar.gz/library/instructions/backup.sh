#!/bin/bash
set -e

#Sauvegarde. Exercice 3.2

#J'ai manqué de temps pour trouver les commandes pour cette exercice

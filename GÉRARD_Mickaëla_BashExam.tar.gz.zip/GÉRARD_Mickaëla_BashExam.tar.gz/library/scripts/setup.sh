 #Création de l'environnement exercice 1.1

#!/bin/bash
set -e

script ~/library/scripts/logger.txt
chmod 777 ~/library/scripts/logger.txt

if [ ! -d ~/library ]; then
mkdir ~/library
fi
chmod 766 ~/library

if [ ! -f ~/library/books.txt ]; then
touch ~/library/books.txt #Base de données des livres
fi
chmod 766 ~/library/books.txt
 #Tout les droits au propriétaire et droits d'écriture et de lecture pour le groupe et les autres utilisateurs

if [ ! -f ~/library/users.txt ]; then
touch ~/library/users.txt #Base de données des utilisateurs
fi
echo "#Base des données des utilisateurs" | cat >> ~/library/users.txt
chmod 766 ~/library/users.txt

if [ ! -d ~/library/logs ]; then
mkdir ~/library/logs #Dossier des journaux
fi
chmod 766 ~/library/logs

if [ ! -d ~/library/scripts ]; then
mkdir scripts #Mes scripts
fi
chmod 766 ~/library/scripts


#Création d'un fichier qui documente chaque étape

if [ ! -f ~/library/scripts/setup.log ]; then
touch ~/library/scripts/setup.log
fi
chmod 766 ~/library/scripts/setup.log
echo "#Liste de chaque étape" | cat >> ~/library/scripts/setup.log
